/**
 * भंडारा चंदा रसीद — Google Sheet ऑनलाइन सर्वर
 * इसे Google Sheet → Extensions → Apps Script में पेस्ट करें, फिर Deploy → Web app करें।
 */
const SHEET_NAME = 'Rasid';
const HEAD = ['no', 'date', 'name', 'addr', 'mob', 'amt', 'mode', 'by', 'ts', 'deleted'];

function sheet_() {
  const ss = SpreadsheetApp.getActive();
  let s = ss.getSheetByName(SHEET_NAME);
  if (!s) {
    s = ss.insertSheet(SHEET_NAME);
    s.appendRow(['रसीद सं. (no)', 'दिनांक (date)', 'नाम (name)', 'पता (addr)', 'मोबाइल (mob)',
                 'राशि (amt)', 'भुगतान (mode)', 'काटने वाला (by)', 'ts', 'हटाई गई (deleted)']);
    s.setFrozenRows(1);
    s.getRange('A:E').setNumberFormat('@'); // text, so dates & mobile numbers stay as typed
  }
  return s;
}

function out_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

function rows_() {
  const v = sheet_().getDataRange().getDisplayValues();
  v.shift();
  return v.filter(r => r[0] !== '').map(r => {
    const o = {};
    HEAD.forEach((k, i) => (o[k] = r[i]));
    return o;
  });
}

function doGet() {
  return out_({ ok: true, recs: rows_().filter(r => !r.deleted) });
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const d = JSON.parse(e.postData.contents);
    const s = sheet_();
    const all = rows_();

    if (d.action === 'add') {
      const r = d.rec || {};
      if (!r.name || !(Number(r.amt) > 0)) return out_({ ok: false, error: 'name/amt missing' });
      const used = new Set(all.map(x => Number(x.no)));
      let no = Number(r.no) || 1;
      while (used.has(no)) no++;          // दो फ़ोन एक साथ भी कटें तो नंबर डबल नहीं होगा
      r.no = no;
      s.appendRow([String(no), String(r.date || ''), String(r.name), String(r.addr || ''), String(r.mob || ''),
                   Number(r.amt), r.mode || 'नकद', r.by || '', r.ts || Date.now(), '']);
      return out_({ ok: true, rec: r });
    }

    if (d.action === 'del') {
      const v = s.getRange(1, 1, s.getLastRow(), 1).getDisplayValues();
      for (let i = 1; i < v.length; i++) {
        if (Number(v[i][0]) === Number(d.no)) s.getRange(i + 1, 10).setValue('yes');
      }
      return out_({ ok: true });
    }

    return out_({ ok: false, error: 'unknown action' });
  } finally {
    lock.releaseLock();
  }
}
