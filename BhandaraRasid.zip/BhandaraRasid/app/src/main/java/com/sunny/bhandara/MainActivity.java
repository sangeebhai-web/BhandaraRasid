package com.sunny.bhandara;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.*;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCb;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true); // Google Sheet से ऑनलाइन जुड़ने के लिए
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (u.getScheme() != null && u.getScheme().startsWith("http") && !u.getHost().contains("fonts.")) {
                    startActivity(new Intent(Intent.ACTION_VIEW, u)); return true;
                }
                return false;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
                startActivityForResult(Intent.createChooser(i, "बैकअप फ़ाइल चुनें"), 7);
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == 7 && fileCb != null) {
            fileCb.onReceiveValue(res == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null);
            fileCb = null;
        }
    }

    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }

    private static byte[] decode(String dataUrl) { return Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT); }

    class Bridge {
        @JavascriptInterface public void shareImage(String dataUrl, String name, String text, String mob) {
            try {
                File dir = new File(getCacheDir(), "share"); dir.mkdirs();
                File f = new File(dir, name);
                try (FileOutputStream o = new FileOutputStream(f)) { o.write(decode(dataUrl)); }
                Uri uri = FileProvider.getUriForFile(MainActivity.this, "com.sunny.bhandara.files", f);
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("image/jpeg");
                i.putExtra(Intent.EXTRA_STREAM, uri);
                i.putExtra(Intent.EXTRA_TEXT, text);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                if (mob != null && mob.length() == 10) {
                    Intent wa = new Intent(i); wa.setPackage("com.whatsapp");
                    wa.putExtra("jid", "91" + mob + "@s.whatsapp.net");
                    try { startActivity(wa); return; } catch (Exception ignored) {}
                }
                startActivity(Intent.createChooser(i, "रसीद भेजें"));
            } catch (Exception e) { toast("शेयर नहीं हो पाया: " + e.getMessage()); }
        }

        @JavascriptInterface public void saveFile(String dataUrl, String name) {
            try {
                byte[] data = decode(dataUrl);
                String mime = name.endsWith(".csv") ? "text/csv" : name.endsWith(".json") ? "application/json" : "image/jpeg";
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/BhandaraRasid");
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(data); }
                } else {
                    File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "BhandaraRasid");
                    dir.mkdirs();
                    try (FileOutputStream o = new FileOutputStream(new File(dir, name))) { o.write(data); }
                }
                toast("Download/BhandaraRasid में सेव हुआ ✅");
            } catch (Exception e) { toast("सेव नहीं हो पाया: " + e.getMessage()); }
        }
    }

    private void toast(String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show()); }
}
