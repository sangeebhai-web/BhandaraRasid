# भंडारा चंदा रसीद — Android App (ऑनलाइन)

## स्टेप 1: Google Sheet को ऑनलाइन सर्वर बनाएँ (एक बार, 5 मिनट)
1. sheets.google.com पर नई Sheet बनाएँ, नाम रखें "भंडारा चंदा 2026".
2. ऊपर **Extensions → Apps Script** खोलें.
3. वहाँ का सारा कोड हटाकर `GoogleSheet_Code.gs` फ़ाइल का पूरा कोड पेस्ट करें → 💾 Save.
4. **Deploy → New deployment** → ⚙️ में **Web app** चुनें:
   - Execute as: **Me**
   - Who has access: **Anyone**
5. **Deploy** → Google अनुमति माँगेगा → Allow करें ("Advanced → Go to project" दबाना पड़ सकता है).
6. जो **Web app URL** मिले (`https://script.google.com/macros/s/..../exec`) उसे कॉपी करें.

## स्टेप 2: लिंक ऐप में डालें (दो में से एक तरीका)
- **आसान:** APK इंस्टॉल करके हर फ़ोन में **सेटिंग → Google Sheet ऑनलाइन लिंक** में URL पेस्ट करें → सेव.
- **सबसे अच्छा:** `app/src/main/assets/index.html` में `SHEET_URL_DEFAULT=''` ढूँढें और `''` के बीच URL डाल दें. फिर APK बनाएँ — हर फ़ोन अपने-आप ऑनलाइन जुड़ जाएगा.

ऐप में ऊपर **🟢 ऑनलाइन (Sheet)** दिखे तो सब जुड़ गया. हर रसीद Sheet में एक लाइन बनकर तुरंत दिखेगी.

## स्टेप 3: APK बनाएँ (मुफ़्त, बिना Android Studio)
1. github.com पर नया repository बनाएँ (जैसे `BhandaraRasid`).
2. इस ZIP के अंदर की सारी फ़ाइलें (`.github` फ़ोल्डर सहित) उसमें Upload करें → Commit.
3. **Actions** टैब → "Build APK" अपने-आप चलेगा (3–5 मिनट).
4. हरा ✅ आने पर run खोलें → नीचे **Artifacts** से `BhandaraRasid-APK` डाउनलोड करें.
5. ZIP खोलकर `BhandaraRasid.apk` फ़ोन में इंस्टॉल करें ("Unknown sources" की अनुमति दें).

## ध्यान दें
- Sheet का URL सिर्फ़ अपनी टीम को दें — जिसके पास लिंक है वह रसीद जोड़ सकता है.
- रसीद हटाने पर Sheet में लाइन मिटती नहीं, "हटाई गई = yes" लिख जाता है (हिसाब सुरक्षित रहता है).
- Apps Script का कोड बदलें तो **Deploy → Manage deployments → Edit → New version** करें.
